#!/bin/sh
set -e
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
python3 cantor_explorer.py
