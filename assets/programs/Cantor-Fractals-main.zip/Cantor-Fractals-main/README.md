# Self-Affine Fractal Generator

A small static website for constructing self-affine rectangle fractals in the browser.

## What it does

- Choose the number of columns `n` and rows `m`.
- Click cells in the grid to select the affine rectangles to keep.
- Changing `n` or `m` updates the grid immediately while preserving overlapping cells.
- Choose the iteration depth `k`, output resolution, and colors.
- Render the approximation on an HTML canvas. The 2D page auto-renders after rule/specification changes.
- Animate stages `0, 1, ..., k`.
- Download the rendered stage as a PNG.

The renderer follows the same point-membership idea as the reference Python script: each output pixel is mapped through repeated base-`n` and base-`m` grid addresses, and it remains black only if every visited rectangle was retained. The current browser renderer precomputes the horizontal and vertical address digits once per stage, then reuses those tables while filling pixels.

## Running locally

Open `index.html` directly in a browser, or serve the folder with a local static server:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Files

- `index.html` - page structure
- `style.css` - visual layout
- `app.js` - grid editor, renderer, animation, and PNG export

No external JavaScript libraries are required.


## 3D page

Open `3d.html` for the three-dimensional version. It uses an `n x m x p` retained-box mask, edits one `z`-slice at a time, computes the stage-`k` occupied voxel grid by recursively expanding only retained addresses, and draws one interactive exterior perspective with the faster version-11-style boundary-surface renderer. Changing `n`, `m`, or `p` updates the slice grid immediately while preserving overlapping retained boxes, and changes to the rule, stage, render size, quality, or colors auto-render. There is no fixed full-grid scan cap; very large choices may still be limited by browser memory and CPU time.

Additional file:

- `3d.html` - three-dimensional page structure
- `3d.js` - 3D mask editor, voxel stage construction, single-view interactive rendering, PNG export, and 30 fps GIF orbit export


The 3D page also includes a button labeled `Download 30 fps orbit GIF`. It exports a four-second animated GIF at 30 frames per second. The animation rotates the camera around the object while advancing through stages 1, 2, 3, and 4. The exporter is dependency-free: it renders canvas frames using the same boundary-surface logic, maps them to a fixed 256-color GIF palette, and writes a conservative LZW GIF stream.


## 3D rendering note

This build reverts the 3D renderer to the faster version-11-style path. It recursively expands retained addresses, extracts only boundary faces, reuses cached stage geometry when the camera or quality changes, and draws the faces with a lightweight camera projection. This is more responsive than the later per-pixel hidden-surface path, especially while rotating or zooming. The tradeoff is that painter-style surface drawing is an approximation for very concave or highly perforated voxel sets; if exact occlusion becomes more important than interaction speed, the z-buffer path can be restored as a high-quality mode.

## 3D animation export note

The 30 fps GIF export uses the same boundary-surface renderer and robust literal LZW encoding with frequent clear codes. This produces larger files than full LZW compression, but avoids the decoder corruption that can show up as a thin valid strip followed by blank or noisy output. The orbit animation advances through stages 1, 2, 3, and 4.

## Current improvements

The 3D page now includes interactive camera controls: drag the rendered view to rotate the camera, and use the mouse wheel over the view to zoom. A render-quality slider controls the internal canvas resolution, so previews can be faster while full-quality exports remain available. The grid controls on the 3D page mirror the 2D page: changing the scale immediately redraws the selector and schedules a new render.

The 3D stage builder caches occupied voxel stages for the current mask. If only the camera or quality changes, the page reuses the cached stage instead of rebuilding the affine address expansion. The orbit GIF also reuses those cached stages.

The 2D page now displays mathematical metadata for the current rule: retained boxes, retention ratio, stage address count, stage grid size, a similarity-dimension estimate when the grid is square, a coarse exponent otherwise, and resolution warnings when the chosen stage is likely finer than the rendered image. The grid selector updates as soon as `n` or `m` changes, and the rendered fractal is recomputed automatically after changes to the rule, stage, resolution, or colors.

Both pages include more presets. The 2D page adds full square, Cantor bars, checker dust, an uneven Bedford-McMullen-style example, and two Cohen-style line-obstruction examples. The 3D page adds alternating slabs, a hollow cube frame, and a 3D diagonal chain.

The 2D page uses a non-sticky controls panel and responsive function controls so native select menus and analysis controls do not overlap the heat-map section on narrower screens.

## Function and Fourier heat maps

The 2D page includes a section below the rendered fractal for scalar functions on the retained stage. It can generate random continuous trigonometric fields, discontinuous noise, coordinate functions, linear functions, sinusoidal examples, radial bumps, address-checker examples, and examples modeled on Alex Cohen's paper on discrete 2D Cantor sets: a point localizer, torus character, vertical line packet, diagonal line packet, and skew line packet. These examples are not copied formulas; they are interactive model functions for the paper's mechanisms: localization on a fractal set, unitary discrete Fourier analysis, and line/coset obstructions.

The function is first sampled on the whole square grid and, when nonzero, normalized so its whole-grid discrete L2 norm is 1. It is then restricted to the retained approximation `E` by multiplying by `1_E`. The function heat map is drawn only on retained sample pixels.

The Fourier panel computes a radix-2 two-dimensional FFT of `1_E f` after extension by zero off the retained set, converts it to the unitary DFT normalization, centers the frequency display, and then masks the Fourier heat map by the same retained set `E`. Outside `E`, both heat maps are blank.

The reported quantities now focus on restricted L2 mass: `||1_E f||_2` for the function restricted to the retained approximation and `||1_E F(1_E f)||_2` for the Fourier transform restricted to the same fractal mask in the centered frequency display. The panel also reports the full `||F(1_E f)||_2` only as a Parseval check, together with retained sample pixels, estimated area, mean on the set, RMS on the set, and the observed Parseval difference.

## 3D function and Fourier slice heat maps

The 3D page now includes a function/Fourier section beneath the interactive perspective. It reuses the 2D page's heat-map and radix-2 unitary FFT code with minimal structural changes: instead of sampling a planar retained set directly, it samples a horizontal `z`-slice of the stage-`k` three-dimensional retained set.

For a chosen sample size and depth-slice index, the page computes the retained slice mask by testing the base-`n`, base-`m`, and base-`p` address digits against the current 3D retained-box rule. It then generates a scalar or complex-valued function using `x`, `y`, and `z` coordinates, restricts it to the retained slice `E_z`, computes the centered unitary 2D FFT of the zero extension, and draws both the function heat map and Fourier magnitude heat map masked by the same retained slice.
