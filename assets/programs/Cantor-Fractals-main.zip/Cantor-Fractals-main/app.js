'use strict';

const els = {
  columns: document.getElementById('columns'),
  rows: document.getElementById('rows'),
  iterations: document.getElementById('iterations'),
  resolution: document.getElementById('resolution'),
  foreground: document.getElementById('foreground'),
  background: document.getElementById('background'),
  density: document.getElementById('density'),
  densityLabel: document.getElementById('densityLabel'),
  applyGrid: document.getElementById('applyGrid'),
  render: document.getElementById('render'),
  animate: document.getElementById('animate'),
  clear: document.getElementById('clear'),
  fill: document.getElementById('fill'),
  invert: document.getElementById('invert'),
  random: document.getElementById('random'),
  preset: document.getElementById('preset'),
  loadPreset: document.getElementById('loadPreset'),
  download: document.getElementById('download'),
  status: document.getElementById('status'),
  keptCount: document.getElementById('keptCount'),
  stageBadge: document.getElementById('stageBadge'),
  outputMeta: document.getElementById('outputMeta'),
  mathMeta: document.getElementById('mathMeta'),
  gridCanvas: document.getElementById('gridCanvas'),
  resultCanvas: document.getElementById('resultCanvas'),
  functionChoice: document.getElementById('functionChoice'),
  functionSize: document.getElementById('functionSize'),
  functionContinuity: document.getElementById('functionContinuity'),
  functionSeed: document.getElementById('functionSeed'),
  generateFunction: document.getElementById('generateFunction'),
  randomizeFunctionSeed: document.getElementById('randomizeFunctionSeed'),
  functionMeta: document.getElementById('functionMeta'),
  functionBadge: document.getElementById('functionBadge'),
  functionCanvas: document.getElementById('functionCanvas'),
  fourierCanvas: document.getElementById('fourierCanvas')
};

const presets = {
  carpet: {
    n: 3,
    m: 3,
    cells: [[0, 0], [0, 1], [0, 2], [1, 0], [1, 2], [2, 0], [2, 1], [2, 2]]
  },
  corners: {
    n: 3,
    m: 3,
    cells: [[0, 0], [0, 2], [2, 0], [2, 2]]
  },
  diagonal: {
    n: 4,
    m: 3,
    cells: [[0, 0], [1, 1], [1, 2], [2, 3]]
  },
  columns: {
    n: 5,
    m: 3,
    cells: [[0, 0], [1, 0], [2, 0], [0, 2], [1, 2], [2, 2], [0, 4], [1, 4], [2, 4]]
  },
  cross: {
    n: 5,
    m: 5,
    cells: [[0, 2], [1, 2], [2, 0], [2, 1], [2, 2], [2, 3], [2, 4], [3, 2], [4, 2]]
  },
  full3: {
    n: 3,
    m: 3,
    cells: [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]]
  },
  cantorBars: {
    n: 3,
    m: 3,
    cells: [[0, 0], [0, 2], [1, 0], [1, 2], [2, 0], [2, 2]]
  },
  checker4: {
    n: 4,
    m: 4,
    cells: [[0, 0], [0, 2], [1, 1], [1, 3], [2, 0], [2, 2], [3, 1], [3, 3]]
  },
  bedfordColumns: {
    n: 6,
    m: 4,
    cells: [[0, 0], [1, 0], [3, 0], [0, 2], [2, 2], [3, 2], [1, 4], [2, 4], [0, 5], [3, 5]]
  },
  cohenLines: {
    n: 5,
    m: 5,
    cells: [[0, 2], [1, 2], [2, 0], [2, 1], [2, 2], [2, 3], [2, 4], [3, 2], [4, 2]]
  },
  cohenSkew: {
    n: 5,
    m: 5,
    cells: [[0, 0], [1, 1], [2, 2], [3, 3], [4, 4], [0, 3], [1, 4], [2, 0], [3, 1], [4, 2]]
  }
};

const state = {
  n: 3,
  m: 3,
  k: 5,
  longerSide: 900,
  mask: createMask(3, 3, false),
  paintValue: null,
  hasRendered: false,
  currentStage: null,
  animating: false,
  animationToken: 0,
  renderToken: 0,
  renderTimer: null,
  functionTimer: null,
  functionReady: false,
  lastFunctionResult: null
};

function createMask(m, n, value) {
  return Array.from({ length: m }, () => Array(n).fill(value));
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  const safe = Number.isFinite(parsed) ? parsed : fallback;
  return Math.max(min, Math.min(max, safe));
}

function formatNumber(value, digits = 4) {
  if (!Number.isFinite(value)) return 'n/a';
  if (value === 0) return '0';
  const abs = Math.abs(value);
  if (abs >= 100000 || abs < 0.0001) return value.toExponential(3);
  return value.toLocaleString(undefined, { maximumSignificantDigits: digits });
}

function readControls(applyDimensions) {
  const nextN = clampInt(els.columns.value, 1, 60, state.n);
  const nextM = clampInt(els.rows.value, 1, 60, state.m);
  state.k = clampInt(els.iterations.value, 0, 14, state.k);
  state.longerSide = clampInt(els.resolution.value, 64, 4096, state.longerSide);

  els.columns.value = String(nextN);
  els.rows.value = String(nextM);
  els.iterations.value = String(state.k);
  els.resolution.value = String(state.longerSide);

  if (applyDimensions && (nextN !== state.n || nextM !== state.m)) {
    resizeMask(nextM, nextN, false);
  }
}

function resizeMask(nextM, nextN, shouldSchedule = true) {
  const next = createMask(nextM, nextN, false);
  const sharedRows = Math.min(state.m, nextM);
  const sharedCols = Math.min(state.n, nextN);

  for (let r = 0; r < sharedRows; r += 1) {
    for (let c = 0; c < sharedCols; c += 1) {
      next[r][c] = state.mask[r][c];
    }
  }

  state.m = nextM;
  state.n = nextN;
  state.mask = next;
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();

  if (shouldSchedule) {
    scheduleRender('Grid scale changed.');
    scheduleFunctionAnalysis();
  }
}

function setStatus(message) {
  els.status.textContent = message;
}

function countKept() {
  let count = 0;
  for (const row of state.mask) {
    for (const value of row) {
      if (value) count += 1;
    }
  }
  return count;
}

function updateKeptCount() {
  const kept = countKept();
  els.keptCount.textContent = `${kept} kept`;
}

function updateMathMeta() {
  if (!els.mathMeta) return;
  const kept = countKept();
  const total = state.n * state.m;
  const ratio = total > 0 ? kept / total : 0;
  const stageWidth = Math.pow(state.n, state.k);
  const stageHeight = Math.pow(state.m, state.k);
  const addressCount = Math.pow(Math.max(kept, 0), state.k);
  const minPixels = Math.min(
    state.n > 1 ? state.longerSide / Math.pow(state.n, state.k) : state.longerSide,
    state.m > 1 ? state.longerSide / Math.pow(state.m, state.k) : state.longerSide
  );

  let dimensionText = 'n/a';
  if (kept > 0 && state.n === state.m && state.n > 1) {
    dimensionText = formatNumber(Math.log(kept) / Math.log(state.n), 5);
  } else if (kept > 0 && state.n > 1 && state.m > 1) {
    dimensionText = `${formatNumber(Math.log(kept) / Math.log(Math.sqrt(state.n * state.m)), 5)} coarse`;
  }

  const warning = minPixels < 1
    ? 'Stage cells are finer than output pixels.'
    : minPixels < 2
      ? 'Stage cells are near pixel scale.'
      : 'Resolution is adequate for this stage.';

  els.mathMeta.innerHTML = [
    metaItem('Retained boxes', `${kept} / ${total}`),
    metaItem('Retention ratio', formatNumber(ratio, 5)),
    metaItem('Stage address count', formatNumber(addressCount, 5)),
    metaItem('Stage grid', `${formatNumber(stageWidth, 5)} x ${formatNumber(stageHeight, 5)}`),
    metaItem('Dimension estimate', dimensionText),
    metaItem('Resolution note', warning)
  ].join('');
}

function metaItem(label, value) {
  return `<div class="meta-item"><span>${label}</span><strong>${value}</strong></div>`;
}

function cssVar(name, fallback) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

function drawGrid() {
  const canvas = els.gridCanvas;
  const wrap = canvas.parentElement;
  const dpr = window.devicePixelRatio || 1;
  const availableWidth = Math.max(240, Math.min(760, wrap.clientWidth - 24));
  const maxHeight = 520;
  let cssWidth = availableWidth;
  let cssHeight = Math.max(140, cssWidth * state.m / state.n);

  if (cssHeight > maxHeight) {
    cssHeight = maxHeight;
    cssWidth = Math.max(220, cssHeight * state.n / state.m);
  }

  canvas.style.width = `${Math.round(cssWidth)}px`;
  canvas.style.height = `${Math.round(cssHeight)}px`;
  canvas.width = Math.max(1, Math.round(cssWidth * dpr));
  canvas.height = Math.max(1, Math.round(cssHeight * dpr));

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssWidth, cssHeight);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, cssWidth, cssHeight);

  const cellW = cssWidth / state.n;
  const cellH = cssHeight / state.m;
  ctx.fillStyle = cssVar('--accent', '#2457d6');

  for (let r = 0; r < state.m; r += 1) {
    for (let c = 0; c < state.n; c += 1) {
      if (state.mask[r][c]) {
        ctx.fillRect(c * cellW, r * cellH, cellW, cellH);
      }
    }
  }

  const dense = state.n > 35 || state.m > 35;
  ctx.lineWidth = dense ? 0.5 : 1;

  ctx.beginPath();
  ctx.strokeStyle = dense ? 'rgba(239, 68, 68, 0.35)' : 'rgba(239, 68, 68, 0.65)';
  for (let c = 0; c <= state.n; c += 1) {
    const x = c * cellW;
    ctx.moveTo(x, 0);
    ctx.lineTo(x, cssHeight);
  }
  ctx.stroke();

  ctx.beginPath();
  ctx.strokeStyle = dense ? 'rgba(37, 99, 235, 0.35)' : 'rgba(37, 99, 235, 0.65)';
  for (let r = 0; r <= state.m; r += 1) {
    const y = r * cellH;
    ctx.moveTo(0, y);
    ctx.lineTo(cssWidth, y);
  }
  ctx.stroke();
}

function cellFromPointer(event) {
  const rect = els.gridCanvas.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;

  if (x < 0 || y < 0 || x >= rect.width || y >= rect.height) {
    return null;
  }

  return {
    row: Math.min(state.m - 1, Math.floor(y / rect.height * state.m)),
    col: Math.min(state.n - 1, Math.floor(x / rect.width * state.n))
  };
}

function setCell(row, col, value) {
  if (state.mask[row][col] === value) return;
  state.mask[row][col] = value;
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();
  scheduleRender('Retained-cell rule changed.');
  scheduleFunctionAnalysis();
}

function onPointerDown(event) {
  event.preventDefault();
  const hit = cellFromPointer(event);
  if (!hit) return;

  state.paintValue = !state.mask[hit.row][hit.col];
  setCell(hit.row, hit.col, state.paintValue);
  els.gridCanvas.setPointerCapture(event.pointerId);
}

function onPointerMove(event) {
  if (state.paintValue === null) return;
  const hit = cellFromPointer(event);
  if (!hit) return;
  setCell(hit.row, hit.col, state.paintValue);
}

function stopPainting(event) {
  state.paintValue = null;
  if (event && els.gridCanvas.hasPointerCapture(event.pointerId)) {
    els.gridCanvas.releasePointerCapture(event.pointerId);
  }
}

function fillMask(value) {
  for (let r = 0; r < state.m; r += 1) {
    for (let c = 0; c < state.n; c += 1) {
      state.mask[r][c] = value;
    }
  }
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();
  scheduleRender(value ? 'Filled the grid.' : 'Cleared the grid.');
  scheduleFunctionAnalysis();
}

function invertMask() {
  for (let r = 0; r < state.m; r += 1) {
    for (let c = 0; c < state.n; c += 1) {
      state.mask[r][c] = !state.mask[r][c];
    }
  }
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();
  scheduleRender('Inverted the grid.');
  scheduleFunctionAnalysis();
}

function randomMask() {
  const probability = Number(els.density.value) / 100;
  for (let r = 0; r < state.m; r += 1) {
    for (let c = 0; c < state.n; c += 1) {
      state.mask[r][c] = Math.random() < probability;
    }
  }
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();
  scheduleRender(`Randomized the grid at ${els.density.value}% density.`);
  scheduleFunctionAnalysis();
}

function loadPreset(name) {
  const preset = presets[name] || presets.carpet;
  state.n = preset.n;
  state.m = preset.m;
  state.mask = createMask(preset.m, preset.n, false);

  for (const [row, col] of preset.cells) {
    if (row >= 0 && row < preset.m && col >= 0 && col < preset.n) {
      state.mask[row][col] = true;
    }
  }

  els.columns.value = String(state.n);
  els.rows.value = String(state.m);
  state.hasRendered = false;
  drawGrid();
  updateKeptCount();
  updateMathMeta();
  scheduleRender(`Loaded preset with ${countKept()} retained boxes.`);
  scheduleFunctionAnalysis();
}

function computeOutputSize(longerSide, aspectWidth, aspectHeight) {
  if (aspectWidth >= aspectHeight) {
    return {
      width: longerSide,
      height: Math.max(1, Math.round(longerSide * aspectHeight / aspectWidth))
    };
  }

  return {
    width: Math.max(1, Math.round(longerSide * aspectWidth / aspectHeight)),
    height: longerSide
  };
}

function hexToRgb(hex) {
  const cleaned = String(hex).replace('#', '').trim();
  if (/^[0-9a-fA-F]{3}$/.test(cleaned)) {
    return cleaned.split('').map(ch => Number.parseInt(ch + ch, 16));
  }
  if (/^[0-9a-fA-F]{6}$/.test(cleaned)) {
    return [
      Number.parseInt(cleaned.slice(0, 2), 16),
      Number.parseInt(cleaned.slice(2, 4), 16),
      Number.parseInt(cleaned.slice(4, 6), 16)
    ];
  }
  return [0, 0, 0];
}

function setBusy(isBusy, allowAnimationStop) {
  const buttons = [
    els.applyGrid,
    els.render,
    els.clear,
    els.fill,
    els.invert,
    els.random,
    els.loadPreset,
    els.download
  ];

  for (const button of buttons) {
    if (button) button.disabled = isBusy;
  }

  if (els.animate) els.animate.disabled = isBusy && !allowAnimationStop;
}

function yieldToBrowser() {
  return new Promise(resolve => window.setTimeout(resolve, 0));
}

function wait(ms) {
  return new Promise(resolve => window.setTimeout(resolve, ms));
}

function drawEmptyResult() {
  const canvas = els.resultCanvas;
  canvas.width = 900;
  canvas.height = 900;
  canvas.style.aspectRatio = '1 / 1';
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#667085';
  ctx.font = '32px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Render a mask to begin', canvas.width / 2, canvas.height / 2);
}

function computeDigits(length, base, stage) {
  const digits = Array.from({ length: stage }, () => new Uint16Array(length));

  for (let i = 0; i < length; i += 1) {
    let value = (i + 0.5) / length;
    for (let s = 0; s < stage; s += 1) {
      let digit = Math.floor(value * base);
      if (digit < 0) digit = 0;
      if (digit >= base) digit = base - 1;
      digits[s][i] = digit;
      value = value * base - digit;
    }
  }

  return digits;
}

function computeRetainedMask(outW, outH, stage) {
  const result = new Uint8Array(outW * outH);
  if (stage === 0) {
    result.fill(1);
    return result;
  }

  if (countKept() === 0) return result;

  const xDigits = computeDigits(outW, state.n, stage);
  const yDigits = computeDigits(outH, state.m, stage);

  for (let y = 0; y < outH; y += 1) {
    const rowDigits = yDigits.map(digits => digits[y]);
    const rowOffset = y * outW;
    for (let x = 0; x < outW; x += 1) {
      let alive = 1;
      for (let s = 0; s < stage; s += 1) {
        if (!state.mask[rowDigits[s]][xDigits[s][x]]) {
          alive = 0;
          break;
        }
      }
      result[rowOffset + x] = alive;
    }
  }

  return result;
}

async function renderFractal(stageOverride, options = {}) {
  const partOfAnimation = options.partOfAnimation === true;
  if (!partOfAnimation) stopAnimation(false);

  readControls(true);
  updateMathMeta();

  const stage = Number.isInteger(stageOverride) ? stageOverride : state.k;
  const kept = countKept();
  const { width: outW, height: outH } = computeOutputSize(state.longerSide, state.n, state.m);
  const token = ++state.renderToken;
  const canvas = els.resultCanvas;
  const ctx = canvas.getContext('2d');
  const fg = hexToRgb(els.foreground.value);
  const bg = hexToRgb(els.background.value);

  canvas.width = outW;
  canvas.height = outH;
  canvas.style.aspectRatio = `${outW} / ${outH}`;
  ctx.fillStyle = els.background.value;
  ctx.fillRect(0, 0, outW, outH);

  state.currentStage = stage;
  els.stageBadge.textContent = `stage ${stage}`;
  els.outputMeta.textContent = `grid = ${state.n} x ${state.m}, output = ${outW} x ${outH}`;
  setBusy(true, partOfAnimation);

  if (stage > 0 && kept === 0) {
    state.hasRendered = true;
    setStatus('No boxes are retained. The stage is empty.');
    setBusy(false, false);
    return true;
  }

  const started = performance.now();

  try {
    const retained = computeRetainedMask(outW, outH, stage);
    const chunkRows = Math.max(1, Math.min(160, Math.floor(240000 / outW)));

    for (let y0 = 0; y0 < outH; y0 += chunkRows) {
      if (token !== state.renderToken) return false;

      const y1 = Math.min(y0 + chunkRows, outH);
      const chunkHeight = y1 - y0;
      const imageData = ctx.createImageData(outW, chunkHeight);
      const data = imageData.data;
      let offset = 0;

      for (let y = y0; y < y1; y += 1) {
        const maskOffset = y * outW;
        for (let x = 0; x < outW; x += 1) {
          const color = retained[maskOffset + x] ? fg : bg;
          data[offset] = color[0];
          data[offset + 1] = color[1];
          data[offset + 2] = color[2];
          data[offset + 3] = 255;
          offset += 4;
        }
      }

      ctx.putImageData(imageData, 0, y0);
      const percent = Math.round(y1 / outH * 100);
      setStatus(`Rendering stage ${stage}: ${percent}% complete.`);
      await yieldToBrowser();
    }

    if (token !== state.renderToken) return false;

    const seconds = ((performance.now() - started) / 1000).toFixed(2);
    state.hasRendered = true;
    setStatus(`Rendered stage ${stage}. Kept boxes: ${kept}. Pixel tests: ${(outW * outH * Math.max(stage, 1)).toLocaleString()}. Time: ${seconds}s.`);
    return true;
  } finally {
    if (!partOfAnimation || !state.animating) {
      setBusy(false, false);
    }
  }
}

function scheduleRender(reason) {
  if (state.animating) stopAnimation(true);
  if (reason) setStatus(`${reason} Auto-render scheduled.`);
  window.clearTimeout(state.renderTimer);
  state.renderTimer = window.setTimeout(() => {
    renderFractal(null).catch(error => setStatus(`Render failed: ${error.message}`));
  }, 220);
}

async function startAnimation() {
  window.clearTimeout(state.renderTimer);
  readControls(true);
  state.animating = true;
  const localToken = ++state.animationToken;
  els.animate.textContent = 'Stop animation';
  setBusy(true, true);

  let stage = 0;
  while (state.animating && localToken === state.animationToken) {
    const ok = await renderFractal(stage, { partOfAnimation: true });
    if (!ok || !state.animating || localToken !== state.animationToken) break;
    stage = stage >= state.k ? 0 : stage + 1;
    await wait(500);
  }

  if (localToken === state.animationToken) {
    stopAnimation(false);
  }
}

function stopAnimation(cancelRender) {
  if (!state.animating && !cancelRender) return;
  state.animating = false;
  state.animationToken += 1;
  if (cancelRender !== false) {
    state.renderToken += 1;
  }
  els.animate.textContent = 'Animate stages';
  setBusy(false, false);
}

function downloadPng() {
  if (!state.hasRendered) {
    setStatus('Render a fractal before downloading.');
    return;
  }

  const link = document.createElement('a');
  const stage = state.currentStage === null ? state.k : state.currentStage;
  link.download = `self-affine-${state.n}x${state.m}-k${stage}.png`;
  link.href = els.resultCanvas.toDataURL('image/png');
  link.click();
}

function makeRng(seed) {
  let value = seed >>> 0;
  return function rng() {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function standardNormal(rng) {
  const u = Math.max(1e-12, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function createComplexField(size) {
  return {
    real: new Float64Array(size * size),
    imag: new Float64Array(size * size),
    description: ''
  };
}

function chooseRandomMode(choice, continuity) {
  if (choice === 'randomContinuous') return continuity === 'discontinuous' ? 'randomDiscontinuous' : 'randomContinuous';
  if (choice === 'randomDiscontinuous') return continuity === 'continuous' ? 'randomContinuous' : 'randomDiscontinuous';
  return choice;
}

function generateWholeGridFunction(size) {
  const choice = chooseRandomMode(els.functionChoice.value, els.functionContinuity.value);
  const seed = clampInt(els.functionSeed.value, 1, 999999, 12345);
  els.functionSeed.value = String(seed);
  const rng = makeRng(seed);
  const field = createComplexField(size);
  const real = field.real;
  const imag = field.imag;
  const modes = [];

  if (choice === 'randomContinuous') {
    const modeCount = 14;
    for (let j = 0; j < modeCount; j += 1) {
      const ax = 1 + Math.floor(rng() * 5);
      const ay = 1 + Math.floor(rng() * 5);
      const amp = standardNormal(rng) / Math.pow(1 + ax * ax + ay * ay, 0.85);
      const phase = 2 * Math.PI * rng();
      modes.push([ax, ay, amp, phase]);
    }
  }

  for (let y = 0; y < size; y += 1) {
    const yy = (y + 0.5) / size;
    for (let x = 0; x < size; x += 1) {
      const xx = (x + 0.5) / size;
      const i = y * size + x;

      switch (choice) {
        case 'randomContinuous': {
          let value = 0;
          for (const [ax, ay, amp, phase] of modes) {
            value += amp * Math.cos(2 * Math.PI * (ax * xx + ay * yy) + phase);
          }
          real[i] = value;
          field.description = 'continuous random trigonometric field';
          break;
        }
        case 'randomDiscontinuous': {
          real[i] = rng() * 2 - 1;
          field.description = 'discontinuous random pixel noise';
          break;
        }
        case 'x':
          real[i] = xx - 0.5;
          field.description = 'centered x-coordinate';
          break;
        case 'y':
          real[i] = yy - 0.5;
          field.description = 'centered y-coordinate';
          break;
        case 'linear':
          real[i] = xx + yy - 1;
          field.description = 'centered x + y';
          break;
        case 'sine':
          real[i] = Math.sin(2 * Math.PI * (3 * xx + 2 * yy)) + 0.55 * Math.cos(2 * Math.PI * (5 * xx - yy));
          field.description = 'two smooth sinusoidal waves';
          break;
        case 'radial': {
          const dx = xx - 0.5;
          const dy = yy - 0.5;
          real[i] = Math.exp(-42 * (dx * dx + dy * dy));
          field.description = 'radial Gaussian bump';
          break;
        }
        case 'checker': {
          const cx = Math.floor(xx * Math.pow(state.n, Math.min(state.k, 5)));
          const cy = Math.floor(yy * Math.pow(state.m, Math.min(state.k, 5)));
          real[i] = (cx + cy) % 2 === 0 ? 1 : -1;
          field.description = 'checker by finite address parity';
          break;
        }
        case 'cohenPoint': {
          const width = 0.045;
          const dx = xx - 0.5;
          const dy = yy - 0.5;
          real[i] = Math.exp(-(dx * dx + dy * dy) / (2 * width * width));
          field.description = 'Cohen-style point localizer';
          break;
        }
        case 'cohenCharacter': {
          const phase = 2 * Math.PI * (5 * xx + 3 * yy);
          real[i] = Math.cos(phase);
          imag[i] = Math.sin(phase);
          field.description = 'Cohen-style torus character exp(2pi i(5x+3y))';
          break;
        }
        case 'cohenVerticalLine': {
          const dist = Math.abs(xx - 0.5);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.025 * 0.025)) * Math.cos(2 * Math.PI * 5 * yy);
          field.description = 'Cohen-style vertical line packet';
          break;
        }
        case 'cohenDiagonalLine': {
          const dist = Math.abs(xx - yy) / Math.sqrt(2);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.03 * 0.03)) * Math.cos(2 * Math.PI * (4 * xx - 4 * yy));
          field.description = 'Cohen-style diagonal line packet';
          break;
        }
        case 'cohenSkewLine': {
          const dist = Math.abs(2 * xx - yy - 0.35) / Math.sqrt(5);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.03 * 0.03)) * Math.cos(2 * Math.PI * (3 * xx + yy));
          field.description = 'Cohen-style skew line packet';
          break;
        }
        default:
          real[i] = 0;
          field.description = 'zero function';
      }
    }
  }

  const normBefore = l2NormOnSquare(real, imag, null, size);
  let normalized = false;
  let scale = 1;
  if (normBefore > 1e-14) {
    scale = 1 / normBefore;
    for (let i = 0; i < real.length; i += 1) {
      real[i] *= scale;
      imag[i] *= scale;
    }
    normalized = true;
  }

  field.choice = choice;
  field.seed = seed;
  field.normBefore = normBefore;
  field.scale = scale;
  field.normalized = normalized;
  return field;
}

function l2NormOnSquare(real, imag, mask, size) {
  let sum = 0;
  for (let i = 0; i < real.length; i += 1) {
    if (mask && !mask[i]) continue;
    sum += real[i] * real[i] + imag[i] * imag[i];
  }
  return Math.sqrt(sum / (size * size));
}

function meanOnMask(real, imag, mask) {
  let sumReal = 0;
  let sumAbsSq = 0;
  let count = 0;
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    sumReal += real[i];
    sumAbsSq += real[i] * real[i] + imag[i] * imag[i];
    count += 1;
  }
  return {
    meanReal: count ? sumReal / count : 0,
    rmsOnSet: count ? Math.sqrt(sumAbsSq / count) : 0,
    count
  };
}

function fft1d(real, imag, inverse) {
  const n = real.length;
  let j = 0;
  for (let i = 1; i < n; i += 1) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = real[i];
      const ti = imag[i];
      real[i] = real[j];
      imag[i] = imag[j];
      real[j] = tr;
      imag[j] = ti;
    }
  }

  for (let len = 2; len <= n; len <<= 1) {
    const angle = (inverse ? 2 : -2) * Math.PI / len;
    const wLenR = Math.cos(angle);
    const wLenI = Math.sin(angle);
    for (let i = 0; i < n; i += len) {
      let wr = 1;
      let wi = 0;
      const half = len >> 1;
      for (let k = 0; k < half; k += 1) {
        const even = i + k;
        const odd = even + half;
        const ur = real[even];
        const ui = imag[even];
        const vr = real[odd] * wr - imag[odd] * wi;
        const vi = real[odd] * wi + imag[odd] * wr;
        real[even] = ur + vr;
        imag[even] = ui + vi;
        real[odd] = ur - vr;
        imag[odd] = ui - vi;
        const nextWr = wr * wLenR - wi * wLenI;
        wi = wr * wLenI + wi * wLenR;
        wr = nextWr;
      }
    }
  }

  if (inverse) {
    for (let i = 0; i < n; i += 1) {
      real[i] /= n;
      imag[i] /= n;
    }
  }
}

function fft2dUnitary(inputReal, inputImag, size) {
  const real = new Float64Array(inputReal);
  const imag = new Float64Array(inputImag);
  const rowR = new Float64Array(size);
  const rowI = new Float64Array(size);

  for (let y = 0; y < size; y += 1) {
    const offset = y * size;
    for (let x = 0; x < size; x += 1) {
      rowR[x] = real[offset + x];
      rowI[x] = imag[offset + x];
    }
    fft1d(rowR, rowI, false);
    for (let x = 0; x < size; x += 1) {
      real[offset + x] = rowR[x];
      imag[offset + x] = rowI[x];
    }
  }

  const colR = new Float64Array(size);
  const colI = new Float64Array(size);
  for (let x = 0; x < size; x += 1) {
    for (let y = 0; y < size; y += 1) {
      const index = y * size + x;
      colR[y] = real[index];
      colI[y] = imag[index];
    }
    fft1d(colR, colI, false);
    for (let y = 0; y < size; y += 1) {
      const index = y * size + x;
      real[index] = colR[y] / size;
      imag[index] = colI[y] / size;
    }
  }

  return { real, imag };
}

function colorDiverging(value, maxAbs) {
  if (maxAbs <= 1e-14) return [245, 247, 251];
  const t = Math.max(-1, Math.min(1, value / maxAbs));
  if (t >= 0) {
    const u = t;
    return [
      Math.round(250 - 70 * u),
      Math.round(246 - 150 * u),
      Math.round(238 - 170 * u)
    ];
  }
  const u = -t;
  return [
    Math.round(238 - 160 * u),
    Math.round(246 - 120 * u),
    Math.round(250 - 35 * u)
  ];
}

function colorMagnitude(value, maxValue) {
  if (maxValue <= 1e-14) return [245, 247, 251];
  const t = Math.max(0, Math.min(1, value / maxValue));
  return [
    Math.round(250 - 210 * t),
    Math.round(247 - 130 * Math.sqrt(t)),
    Math.round(238 - 20 * t)
  ];
}

function drawFunctionHeatMap(canvas, real, imag, mask, size) {
  canvas.width = size;
  canvas.height = size;
  canvas.style.aspectRatio = '1 / 1';
  const ctx = canvas.getContext('2d');
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  let maxAbs = 0;
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    maxAbs = Math.max(maxAbs, Math.abs(real[i]));
  }

  for (let i = 0; i < mask.length; i += 1) {
    const offset = i * 4;
    if (!mask[i]) {
      data[offset] = 255;
      data[offset + 1] = 255;
      data[offset + 2] = 255;
      data[offset + 3] = 255;
      continue;
    }
    const [r, g, b] = colorDiverging(real[i], maxAbs);
    data[offset] = r;
    data[offset + 1] = g;
    data[offset + 2] = b;
    data[offset + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
}

function drawFourierHeatMap(canvas, fourierReal, fourierImag, mask, size) {
  canvas.width = size;
  canvas.height = size;
  canvas.style.aspectRatio = '1 / 1';
  const ctx = canvas.getContext('2d');
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  const half = size >> 1;
  const visibleLogMag = new Float64Array(size * size);
  let maxLogMag = 0;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const displayIndex = y * size + x;
      if (!mask[displayIndex]) continue;
      const sx = (x + half) % size;
      const sy = (y + half) % size;
      const sourceIndex = sy * size + sx;
      const mag = Math.hypot(fourierReal[sourceIndex], fourierImag[sourceIndex]);
      const logMag = Math.log1p(mag);
      visibleLogMag[displayIndex] = logMag;
      if (logMag > maxLogMag) maxLogMag = logMag;
    }
  }

  for (let i = 0; i < mask.length; i += 1) {
    const offset = i * 4;
    if (!mask[i]) {
      data[offset] = 255;
      data[offset + 1] = 255;
      data[offset + 2] = 255;
      data[offset + 3] = 255;
      continue;
    }
    const [r, g, b] = colorMagnitude(visibleLogMag[i], maxLogMag);
    data[offset] = r;
    data[offset + 1] = g;
    data[offset + 2] = b;
    data[offset + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
}

function restrictFieldToMask(field, mask) {
  const real = new Float64Array(field.real.length);
  const imag = new Float64Array(field.imag.length);
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    real[i] = field.real[i];
    imag[i] = field.imag[i];
  }
  return { real, imag };
}

function l2NormOfCenteredFourierRestrictedToMask(fourierReal, fourierImag, mask, size) {
  const half = size >> 1;
  let sum = 0;
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const displayIndex = y * size + x;
      if (!mask[displayIndex]) continue;
      const sx = (x + half) % size;
      const sy = (y + half) % size;
      const sourceIndex = sy * size + sx;
      sum += fourierReal[sourceIndex] * fourierReal[sourceIndex] + fourierImag[sourceIndex] * fourierImag[sourceIndex];
    }
  }
  return Math.sqrt(sum / (size * size));
}

async function generateFunctionAnalysis() {
  if (!els.functionCanvas || !els.fourierCanvas) return;
  readControls(true);
  updateMathMeta();

  const size = clampInt(els.functionSize.value, 64, 512, 128);
  if ((size & (size - 1)) !== 0) {
    setStatus('Function sample size must be a power of two.');
    return;
  }

  if (els.functionBadge) els.functionBadge.textContent = 'computing';
  await yieldToBrowser();

  const setMask = computeRetainedMask(size, size, state.k);
  const field = generateWholeGridFunction(size);
  const restricted = restrictFieldToMask(field, setMask);
  const fourier = fft2dUnitary(restricted.real, restricted.imag, size);

  drawFunctionHeatMap(els.functionCanvas, restricted.real, restricted.imag, setMask, size);
  drawFourierHeatMap(els.fourierCanvas, fourier.real, fourier.imag, setMask, size);

  const count = setMask.reduce((acc, value) => acc + value, 0);
  const area = count / (size * size);
  const functionL2 = l2NormOnSquare(restricted.real, restricted.imag, null, size);
  const fourierFullL2 = l2NormOnSquare(fourier.real, fourier.imag, null, size);
  const fourierRestrictedL2 = l2NormOfCenteredFourierRestrictedToMask(fourier.real, fourier.imag, setMask, size);
  const stats = meanOnMask(restricted.real, restricted.imag, setMask);
  const parsevalError = Math.abs(functionL2 - fourierFullL2);

  if (els.functionMeta) {
    els.functionMeta.innerHTML = [
      metaItem('Function model', field.description),
      metaItem('Whole-grid normalization', field.normalized ? `||f||_2 = 1, scale ${formatNumber(field.scale, 5)}` : 'not applied'),
      metaItem('Retained sample pixels', `${count.toLocaleString()} / ${(size * size).toLocaleString()}`),
      metaItem('Estimated |E|', formatNumber(area, 6)),
      metaItem('||1_E f||_2', formatNumber(functionL2, 7)),
      metaItem('||1_E F(1_E f)||_2', formatNumber(fourierRestrictedL2, 7)),
      metaItem('Full Parseval check ||F(1_E f)||_2', formatNumber(fourierFullL2, 7)),
      metaItem('Parseval difference', formatNumber(parsevalError, 4)),
      metaItem('Mean of real part on E', formatNumber(stats.meanReal, 6)),
      metaItem('RMS on E', formatNumber(stats.rmsOnSet, 6))
    ].join('');
  }

  if (els.functionBadge) els.functionBadge.textContent = `sample ${size} x ${size}`;
  state.functionReady = true;
  state.lastFunctionResult = {
    size,
    count,
    functionL2,
    fourierRestrictedL2,
    fourierFullL2
  };
  setStatus(`Generated function and Fourier heat maps on the retained set. Restricted Fourier L2 = ${formatNumber(fourierRestrictedL2, 6)}.`);
}

function scheduleFunctionAnalysis() {
  if (!state.functionReady) return;
  window.clearTimeout(state.functionTimer);
  state.functionTimer = window.setTimeout(() => {
    generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
  }, 260);
}

function bindEvents() {
  els.applyGrid.addEventListener('click', () => {
    stopAnimation(true);
    readControls(true);
    drawGrid();
    updateKeptCount();
    updateMathMeta();
    scheduleRender(`Grid is ${state.n} x ${state.m}. Existing overlapping cells were preserved.`);
    scheduleFunctionAnalysis();
  });

  els.render.addEventListener('click', () => {
    window.clearTimeout(state.renderTimer);
    renderFractal(null).catch(error => setStatus(`Render failed: ${error.message}`));
  });

  els.animate.addEventListener('click', () => {
    if (state.animating) {
      stopAnimation(true);
    } else {
      startAnimation().catch(error => {
        stopAnimation(true);
        setStatus(`Animation failed: ${error.message}`);
      });
    }
  });

  els.clear.addEventListener('click', () => {
    stopAnimation(true);
    fillMask(false);
  });

  els.fill.addEventListener('click', () => {
    stopAnimation(true);
    fillMask(true);
  });

  els.invert.addEventListener('click', () => {
    stopAnimation(true);
    invertMask();
  });

  els.random.addEventListener('click', () => {
    stopAnimation(true);
    randomMask();
  });

  els.loadPreset.addEventListener('click', () => {
    stopAnimation(true);
    loadPreset(els.preset.value);
  });

  els.download.addEventListener('click', downloadPng);

  els.density.addEventListener('input', () => {
    els.densityLabel.textContent = `${els.density.value}%`;
  });

  for (const control of [els.columns, els.rows, els.iterations, els.resolution, els.foreground, els.background]) {
    control.addEventListener('input', () => {
      stopAnimation(true);
      readControls(true);
      drawGrid();
      updateKeptCount();
      updateMathMeta();
      state.hasRendered = false;
      scheduleRender('Specification changed.');
      scheduleFunctionAnalysis();
    });
  }

  els.gridCanvas.addEventListener('pointerdown', onPointerDown);
  els.gridCanvas.addEventListener('pointermove', onPointerMove);
  els.gridCanvas.addEventListener('pointerup', stopPainting);
  els.gridCanvas.addEventListener('pointercancel', stopPainting);
  els.gridCanvas.addEventListener('pointerleave', stopPainting);

  if (els.generateFunction) {
    els.generateFunction.addEventListener('click', () => {
      window.clearTimeout(state.functionTimer);
      generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
    });
  }

  if (els.randomizeFunctionSeed) {
    els.randomizeFunctionSeed.addEventListener('click', () => {
      els.functionSeed.value = String(1 + Math.floor(Math.random() * 999999));
      generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
    });
  }

  for (const control of [els.functionChoice, els.functionSize, els.functionContinuity, els.functionSeed]) {
    if (!control) continue;
    control.addEventListener('input', () => {
      state.functionReady = true;
      scheduleFunctionAnalysis();
    });
    control.addEventListener('change', () => {
      state.functionReady = true;
      scheduleFunctionAnalysis();
    });
  }

  window.addEventListener('resize', drawGrid);
}

function init() {
  bindEvents();
  loadPreset('carpet');
  drawEmptyResult();
  if (els.densityLabel) els.densityLabel.textContent = `${els.density.value}%`;
  if (els.functionMeta) {
    els.functionMeta.innerHTML = metaItem('Function analysis', 'Generate heat maps after choosing a function.');
  }
  updateMathMeta();
  setStatus('Ready. Select cells and render.');
}

init();
