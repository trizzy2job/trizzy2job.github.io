'use strict';

const els = {
  columns: document.getElementById('columns'),
  rows: document.getElementById('rows'),
  layers: document.getElementById('layers'),
  iterations: document.getElementById('iterations'),
  resolution: document.getElementById('resolution'),
  slice: document.getElementById('slice'),
  quality: document.getElementById('quality'),
  qualityLabel: document.getElementById('qualityLabel'),
  foreground: document.getElementById('foreground'),
  background: document.getElementById('background'),
  density: document.getElementById('density'),
  densityLabel: document.getElementById('densityLabel'),
  applyGrid: document.getElementById('applyGrid'),
  render: document.getElementById('render'),
  clear: document.getElementById('clear'),
  fill: document.getElementById('fill'),
  invert: document.getElementById('invert'),
  random: document.getElementById('random'),
  preset: document.getElementById('preset'),
  loadPreset: document.getElementById('loadPreset'),
  download: document.getElementById('download'),
  downloadGif: document.getElementById('downloadGif'),
  status: document.getElementById('status'),
  keptCount: document.getElementById('keptCount'),
  stageBadge: document.getElementById('stageBadge'),
  outputMeta: document.getElementById('outputMeta'),
  gridCanvas: document.getElementById('gridCanvas'),
  view: document.getElementById('viewA'),
  functionChoice: document.getElementById('functionChoice'),
  functionSize: document.getElementById('functionSize'),
  functionSlice: document.getElementById('functionSlice'),
  functionContinuity: document.getElementById('functionContinuity'),
  functionSeed: document.getElementById('functionSeed'),
  generateFunction: document.getElementById('generateFunction'),
  randomizeFunctionSeed: document.getElementById('randomizeFunctionSeed'),
  functionMeta: document.getElementById('functionMeta'),
  functionBadge: document.getElementById('functionBadge'),
  functionCanvas: document.getElementById('functionCanvas'),
  fourierCanvas: document.getElementById('fourierCanvas')
};

const state = {
  n: 3,
  m: 3,
  p: 3,
  k: 3,
  viewSize: 560,
  quality: 75,
  z: 0,
  mask: createMask(3, 3, 3, false),
  paintValue: null,
  ruleVersion: 0,
  renderTimer: 0,
  renderSerial: 0,
  isRendering: false,
  hasRendered: false,
  lastStage: null,
  stageCache: new Map(),
  camera: {
    yaw: -0.72,
    pitch: 0.52,
    distance: 8.4,
    fov: 24 * Math.PI / 180
  },
  drag: null,
  functionTimer: 0,
  functionReady: false,
  lastFunctionResult: null
};

function createMask(p, m, n, value) {
  return Array.from({ length: p }, () =>
    Array.from({ length: m }, () => Array(n).fill(value))
  );
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  const safe = Number.isFinite(parsed) ? parsed : fallback;
  return Math.max(min, Math.min(max, safe));
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatNumber(value, digits = 4) {
  if (!Number.isFinite(value)) return 'n/a';
  if (value === 0) return '0';
  const abs = Math.abs(value);
  if (abs >= 100000 || abs < 0.0001) return value.toExponential(3);
  return value.toLocaleString(undefined, { maximumSignificantDigits: digits });
}

function metaItem(label, value) {
  return `<div class="meta-item"><span>${label}</span><strong>${value}</strong></div>`;
}

function setStatus(message) {
  els.status.textContent = message;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function invalidateGeometry() {
  state.ruleVersion += 1;
  state.stageCache.clear();
  state.lastStage = null;
  state.hasRendered = false;
  scheduleFunctionAnalysis();
}

function readControls(applyDimensions) {
  const nextN = clampInt(els.columns.value, 1, 32, state.n);
  const nextM = clampInt(els.rows.value, 1, 32, state.m);
  const nextP = clampInt(els.layers.value, 1, 32, state.p);
  const nextK = clampInt(els.iterations.value, 0, 10, state.k);
  const nextViewSize = clampInt(els.resolution.value, 240, 2200, state.viewSize);
  const nextQuality = clampInt(els.quality ? els.quality.value : state.quality, 35, 100, state.quality);

  els.columns.value = String(nextN);
  els.rows.value = String(nextM);
  els.layers.value = String(nextP);
  els.iterations.value = String(nextK);
  els.resolution.value = String(nextViewSize);
  if (els.quality) {
    els.quality.value = String(nextQuality);
    els.qualityLabel.textContent = `${nextQuality}%`;
  }

  if (applyDimensions && (nextN !== state.n || nextM !== state.m || nextP !== state.p)) {
    resizeMask(nextP, nextM, nextN);
  }

  if (nextK !== state.k) {
    state.k = nextK;
    state.hasRendered = false;
  }
  state.viewSize = nextViewSize;
  state.quality = nextQuality;

  state.z = clampInt(els.slice.value, 0, state.p - 1, state.z);
  els.slice.min = '0';
  els.slice.max = String(state.p - 1);
  els.slice.value = String(state.z);
}

function resizeMask(nextP, nextM, nextN) {
  const next = createMask(nextP, nextM, nextN, false);
  for (let z = 0; z < Math.min(state.p, nextP); z += 1) {
    for (let r = 0; r < Math.min(state.m, nextM); r += 1) {
      for (let c = 0; c < Math.min(state.n, nextN); c += 1) {
        next[z][r][c] = state.mask[z][r][c];
      }
    }
  }
  state.n = nextN;
  state.m = nextM;
  state.p = nextP;
  state.mask = next;
  state.z = Math.min(state.z, state.p - 1);
  invalidateGeometry();
  drawGrid();
  updateKeptCount();
}

function countKept() {
  let count = 0;
  for (const layer of state.mask) {
    for (const row of layer) {
      for (const value of row) {
        if (value) count += 1;
      }
    }
  }
  return count;
}

function retainedRule() {
  const rule = [];
  for (let z = 0; z < state.p; z += 1) {
    for (let y = 0; y < state.m; y += 1) {
      for (let x = 0; x < state.n; x += 1) {
        if (state.mask[z][y][x]) rule.push({ x, y, z });
      }
    }
  }
  return rule;
}

function updateKeptCount() {
  els.keptCount.textContent = `${countKept()} kept`;
}

function cssVar(name, fallback) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

function drawGrid() {
  const canvas = els.gridCanvas;
  const wrap = canvas.parentElement;
  const dpr = window.devicePixelRatio || 1;
  const availableWidth = Math.max(240, Math.min(760, wrap.clientWidth - 24));
  const maxHeight = 520;
  let cssWidth = availableWidth;
  let cssHeight = Math.max(160, cssWidth * state.m / state.n);

  if (cssHeight > maxHeight) {
    cssHeight = maxHeight;
    cssWidth = Math.max(220, cssHeight * state.n / state.m);
  }

  canvas.style.width = `${Math.round(cssWidth)}px`;
  canvas.style.height = `${Math.round(cssHeight)}px`;
  canvas.width = Math.max(1, Math.round(cssWidth * dpr));
  canvas.height = Math.max(1, Math.round(cssHeight * dpr));

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssWidth, cssHeight);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, cssWidth, cssHeight);

  const cellW = cssWidth / state.n;
  const cellH = cssHeight / state.m;
  ctx.fillStyle = cssVar('--accent', '#2457d6');

  for (let r = 0; r < state.m; r += 1) {
    for (let c = 0; c < state.n; c += 1) {
      if (state.mask[state.z][r][c]) {
        ctx.fillRect(c * cellW, r * cellH, cellW, cellH);
      }
    }
  }

  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.68)';
  for (let c = 0; c <= state.n; c += 1) {
    const x = c * cellW;
    ctx.moveTo(x, 0);
    ctx.lineTo(x, cssHeight);
  }
  ctx.stroke();

  ctx.beginPath();
  ctx.strokeStyle = 'rgba(37, 99, 235, 0.68)';
  for (let r = 0; r <= state.m; r += 1) {
    const y = r * cellH;
    ctx.moveTo(0, y);
    ctx.lineTo(cssWidth, y);
  }
  ctx.stroke();

  ctx.fillStyle = '#30394a';
  ctx.font = '700 14px system-ui, sans-serif';
  ctx.fillText(`z-slice ${state.z} of ${state.p - 1}`, 12, 22);
}

function cellFromPointer(event) {
  const rect = els.gridCanvas.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;
  if (x < 0 || y < 0 || x >= rect.width || y >= rect.height) return null;
  return {
    row: Math.min(state.m - 1, Math.floor(y / rect.height * state.m)),
    col: Math.min(state.n - 1, Math.floor(x / rect.width * state.n))
  };
}

function setCell(row, col, value) {
  if (state.mask[state.z][row][col] === value) return;
  state.mask[state.z][row][col] = value;
  invalidateGeometry();
  drawGrid();
  updateKeptCount();
  scheduleRender(260);
}

function onPointerDown(event) {
  event.preventDefault();
  const hit = cellFromPointer(event);
  if (!hit) return;
  state.paintValue = !state.mask[state.z][hit.row][hit.col];
  setCell(hit.row, hit.col, state.paintValue);
  els.gridCanvas.setPointerCapture(event.pointerId);
}

function onPointerMove(event) {
  if (state.paintValue === null) return;
  const hit = cellFromPointer(event);
  if (hit) setCell(hit.row, hit.col, state.paintValue);
}

function stopPainting(event) {
  state.paintValue = null;
  if (event && els.gridCanvas.hasPointerCapture(event.pointerId)) {
    els.gridCanvas.releasePointerCapture(event.pointerId);
  }
}

function fillMask(value) {
  for (let z = 0; z < state.p; z += 1) {
    for (let r = 0; r < state.m; r += 1) {
      for (let c = 0; c < state.n; c += 1) {
        state.mask[z][r][c] = value;
      }
    }
  }
  invalidateGeometry();
  drawGrid();
  updateKeptCount();
  scheduleRender(80);
}

function invertMask() {
  for (let z = 0; z < state.p; z += 1) {
    for (let r = 0; r < state.m; r += 1) {
      for (let c = 0; c < state.n; c += 1) {
        state.mask[z][r][c] = !state.mask[z][r][c];
      }
    }
  }
  invalidateGeometry();
  drawGrid();
  updateKeptCount();
  scheduleRender(80);
}

function randomMask() {
  const probability = Number(els.density.value) / 100;
  for (let z = 0; z < state.p; z += 1) {
    for (let r = 0; r < state.m; r += 1) {
      for (let c = 0; c < state.n; c += 1) {
        state.mask[z][r][c] = Math.random() < probability;
      }
    }
  }
  invalidateGeometry();
  drawGrid();
  updateKeptCount();
  scheduleRender(80);
}

function setMaskDimensions(n, m, p) {
  state.n = n;
  state.m = m;
  state.p = p;
  state.z = Math.min(state.z, p - 1);
  state.mask = createMask(p, m, n, false);
  els.columns.value = String(n);
  els.rows.value = String(m);
  els.layers.value = String(p);
  els.slice.min = '0';
  els.slice.max = String(p - 1);
  els.slice.value = String(state.z);
}

function loadPreset(name) {
  if (name === 'frame') {
    setMaskDimensions(4, 4, 4);
    for (let z = 0; z < 4; z += 1) {
      for (let y = 0; y < 4; y += 1) {
        for (let x = 0; x < 4; x += 1) {
          const onWall = x === 0 || x === 3 || y === 0 || y === 3 || z === 0 || z === 3;
          const onEdge = [x === 0 || x === 3, y === 0 || y === 3, z === 0 || z === 3].filter(Boolean).length >= 2;
          state.mask[z][y][x] = onWall && onEdge;
        }
      }
    }
  } else if (name === 'diagonal3d') {
    setMaskDimensions(4, 4, 4);
    for (let i = 0; i < 4; i += 1) state.mask[i][i][i] = true;
    state.mask[0][3][1] = true;
    state.mask[1][2][2] = true;
    state.mask[2][1][1] = true;
    state.mask[3][0][2] = true;
  } else if (name === 'slab') {
    setMaskDimensions(3, 3, 3);
    for (let z = 0; z < 3; z += 1) {
      for (let y = 0; y < 3; y += 1) {
        for (let x = 0; x < 3; x += 1) {
          state.mask[z][y][x] = (z === 0 && (x + y) % 2 === 0) || (z === 2 && (x + y) % 2 === 1) || (z === 1 && x === 1 && y === 1);
        }
      }
    }
  } else {
    setMaskDimensions(3, 3, 3);
    for (let z = 0; z < 3; z += 1) {
      for (let y = 0; y < 3; y += 1) {
        for (let x = 0; x < 3; x += 1) {
          const centered = [x, y, z].filter(v => v === 1).length;
          let keep = false;
          if (name === 'menger') keep = centered <= 1;
          if (name === 'corners') keep = x !== 1 && y !== 1 && z !== 1;
          if (name === 'cross') keep = (x === 1 && y === 1) || (x === 1 && z === 1) || (y === 1 && z === 1);
          if (name === 'tetra') keep = [0, 2].includes(x) && [0, 2].includes(y) && [0, 2].includes(z) && ((x + y + z) % 4 === 0);
          state.mask[z][y][x] = keep;
        }
      }
    }
  }

  invalidateGeometry();
  drawGrid();
  updateKeptCount();
  setStatus(`Loaded preset with ${countKept()} retained boxes.`);
  scheduleRender(80);
}

function hexToRgb(hex) {
  const cleaned = String(hex).replace('#', '').trim();
  if (/^[0-9a-fA-F]{3}$/.test(cleaned)) {
    return cleaned.split('').map(ch => Number.parseInt(ch + ch, 16));
  }
  if (/^[0-9a-fA-F]{6}$/.test(cleaned)) {
    return [
      Number.parseInt(cleaned.slice(0, 2), 16),
      Number.parseInt(cleaned.slice(2, 4), 16),
      Number.parseInt(cleaned.slice(4, 6), 16)
    ];
  }
  return [0, 0, 0];
}

function rgbString(rgb, factor, alpha = 1) {
  const r = clamp(Math.round(rgb[0] * factor), 0, 255);
  const g = clamp(Math.round(rgb[1] * factor), 0, 255);
  const b = clamp(Math.round(rgb[2] * factor), 0, 255);
  return alpha >= 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function powInt(base, exponent) {
  let value = 1;
  for (let i = 0; i < exponent; i += 1) value *= base;
  return value;
}

function makeStageKey(stage) {
  return `${state.n}x${state.m}x${state.p}|k=${stage}|v=${state.ruleVersion}`;
}

function cellKeyFactory(nx, ny, nz) {
  const total = nx * ny * nz;
  if (Number.isSafeInteger(total) && total < 9e15) {
    const plane = nx * ny;
    return (x, y, z) => x + y * nx + z * plane;
  }
  return (x, y, z) => `${x},${y},${z}`;
}

async function buildStage(stage) {
  const cached = state.stageCache.get(makeStageKey(stage));
  if (cached) return cached;

  const rule = retainedRule();
  const nx = powInt(state.n, stage);
  const ny = powInt(state.m, stage);
  const nz = powInt(state.p, stage);

  let cells = [{ x: 0, y: 0, z: 0 }];
  if (stage > 0 && rule.length === 0) cells = [];

  for (let depth = 0; depth < stage; depth += 1) {
    const next = new Array(cells.length * rule.length);
    let index = 0;
    for (const cell of cells) {
      const baseX = cell.x * state.n;
      const baseY = cell.y * state.m;
      const baseZ = cell.z * state.p;
      for (const box of rule) {
        next[index] = {
          x: baseX + box.x,
          y: baseY + box.y,
          z: baseZ + box.z
        };
        index += 1;
      }
    }
    cells = next;
    if (depth % 2 === 1) await sleep(0);
  }

  const keyOf = cellKeyFactory(nx, ny, nz);
  const occupied = new Set();
  for (const cell of cells) occupied.add(keyOf(cell.x, cell.y, cell.z));

  const faces = buildBoundaryFaces(cells, occupied, keyOf, nx, ny, nz);
  const data = {
    stage,
    nx,
    ny,
    nz,
    cells,
    occupied,
    faces,
    retainedRuleCount: rule.length,
    ruleBoxes: state.n * state.m * state.p
  };

  state.stageCache.set(makeStageKey(stage), data);
  return data;
}

function pushFace(faces, normal, values) {
  faces.push({ n: normal, v: values });
}

function buildBoundaryFaces(cells, occupied, keyOf, nx, ny, nz) {
  const faces = [];
  for (const cell of cells) {
    const x = cell.x;
    const y = cell.y;
    const z = cell.z;

    const x0 = x / nx - 0.5;
    const x1 = (x + 1) / nx - 0.5;
    const y0 = 0.5 - y / ny;
    const y1 = 0.5 - (y + 1) / ny;
    const z0 = z / nz - 0.5;
    const z1 = (z + 1) / nz - 0.5;

    if (x === 0 || !occupied.has(keyOf(x - 1, y, z))) {
      pushFace(faces, [-1, 0, 0], [x0, y1, z1, x0, y0, z1, x0, y0, z0, x0, y1, z0]);
    }
    if (x === nx - 1 || !occupied.has(keyOf(x + 1, y, z))) {
      pushFace(faces, [1, 0, 0], [x1, y1, z0, x1, y0, z0, x1, y0, z1, x1, y1, z1]);
    }
    if (y === 0 || !occupied.has(keyOf(x, y - 1, z))) {
      pushFace(faces, [0, 1, 0], [x0, y0, z0, x0, y0, z1, x1, y0, z1, x1, y0, z0]);
    }
    if (y === ny - 1 || !occupied.has(keyOf(x, y + 1, z))) {
      pushFace(faces, [0, -1, 0], [x0, y1, z1, x0, y1, z0, x1, y1, z0, x1, y1, z1]);
    }
    if (z === 0 || !occupied.has(keyOf(x, y, z - 1))) {
      pushFace(faces, [0, 0, -1], [x1, y1, z0, x1, y0, z0, x0, y0, z0, x0, y1, z0]);
    }
    if (z === nz - 1 || !occupied.has(keyOf(x, y, z + 1))) {
      pushFace(faces, [0, 0, 1], [x0, y1, z1, x0, y0, z1, x1, y0, z1, x1, y1, z1]);
    }
  }
  return faces;
}

function cross(a, b) {
  return [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0]
  ];
}

function dot(a, b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

function normalize(v) {
  const length = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / length, v[1] / length, v[2] / length];
}

function cameraBasis(camera) {
  const pitch = clamp(camera.pitch, -1.32, 1.32);
  const cp = Math.cos(pitch);
  const sp = Math.sin(pitch);
  const pos = [
    camera.distance * cp * Math.sin(camera.yaw),
    camera.distance * sp,
    camera.distance * cp * Math.cos(camera.yaw)
  ];
  const forward = normalize([-pos[0], -pos[1], -pos[2]]);
  let right = normalize(cross(forward, [0, 1, 0]));
  if (Math.hypot(right[0], right[1], right[2]) < 1e-6) right = [1, 0, 0];
  const up = normalize(cross(right, forward));
  return { pos, forward, right, up };
}

function projectPoint(x, y, z, basis, size, fov) {
  const vx = x - basis.pos[0];
  const vy = y - basis.pos[1];
  const vz = z - basis.pos[2];
  const cx = vx * basis.right[0] + vy * basis.right[1] + vz * basis.right[2];
  const cy = vx * basis.up[0] + vy * basis.up[1] + vz * basis.up[2];
  const depth = vx * basis.forward[0] + vy * basis.forward[1] + vz * basis.forward[2];
  if (depth <= 0.001) return null;
  const scale = size / (2 * Math.tan(fov / 2));
  return {
    x: size / 2 + cx * scale / depth,
    y: size / 2 - cy * scale / depth,
    depth
  };
}

function drawBoundingCube(ctx, basis, size, fov) {
  const points = [
    [-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5],
    [-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5]
  ].map(p => projectPoint(p[0], p[1], p[2], basis, size, fov));
  const edges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
  ctx.save();
  ctx.strokeStyle = 'rgba(48, 57, 74, 0.26)';
  ctx.lineWidth = Math.max(1, size / 520);
  ctx.beginPath();
  for (const [a, b] of edges) {
    if (!points[a] || !points[b]) continue;
    ctx.moveTo(points[a].x, points[a].y);
    ctx.lineTo(points[b].x, points[b].y);
  }
  ctx.stroke();
  ctx.restore();
}

function renderScene(canvas, stageData, camera, options = {}) {
  const displaySize = options.displaySize || state.viewSize;
  const quality = options.quality || state.quality;
  const pixelSize = options.pixelSize || Math.max(160, Math.round(displaySize * quality / 100));
  const showOverlay = options.showOverlay !== false;

  canvas.style.width = `${displaySize}px`;
  canvas.style.height = `${displaySize}px`;
  canvas.width = pixelSize;
  canvas.height = pixelSize;

  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = els.background.value;
  ctx.fillRect(0, 0, pixelSize, pixelSize);

  const basis = cameraBasis(camera);
  drawBoundingCube(ctx, basis, pixelSize, camera.fov);

  const fg = hexToRgb(els.foreground.value);
  const light = normalize([-0.35, 0.78, 0.52]);
  const projected = [];
  const outline = stageData.faces.length <= 12000;

  for (const face of stageData.faces) {
    let cx = 0;
    let cy = 0;
    let cz = 0;
    for (let i = 0; i < 12; i += 3) {
      cx += face.v[i];
      cy += face.v[i + 1];
      cz += face.v[i + 2];
    }
    cx /= 4;
    cy /= 4;
    cz /= 4;

    const toCamera = [basis.pos[0] - cx, basis.pos[1] - cy, basis.pos[2] - cz];
    if (dot(face.n, toCamera) <= -0.0001) continue;

    const pts = [];
    let depth = 0;
    let visible = true;
    for (let i = 0; i < 12; i += 3) {
      const p = projectPoint(face.v[i], face.v[i + 1], face.v[i + 2], basis, pixelSize, camera.fov);
      if (!p) {
        visible = false;
        break;
      }
      pts.push(p);
      depth += p.depth;
    }
    if (!visible) continue;

    const minX = Math.min(pts[0].x, pts[1].x, pts[2].x, pts[3].x);
    const maxX = Math.max(pts[0].x, pts[1].x, pts[2].x, pts[3].x);
    const minY = Math.min(pts[0].y, pts[1].y, pts[2].y, pts[3].y);
    const maxY = Math.max(pts[0].y, pts[1].y, pts[2].y, pts[3].y);
    if (maxX < -4 || minX > pixelSize + 4 || maxY < -4 || minY > pixelSize + 4) continue;

    const diffuse = Math.max(0, dot(face.n, light));
    const facing = clamp(dot(face.n, normalize(toCamera)), 0, 1);
    const shade = 0.46 + 0.34 * diffuse + 0.18 * facing;
    projected.push({ pts, depth: depth / 4, color: rgbString(fg, shade), outline });
  }

  projected.sort((a, b) => b.depth - a.depth);

  for (const face of projected) {
    ctx.beginPath();
    ctx.moveTo(face.pts[0].x, face.pts[0].y);
    ctx.lineTo(face.pts[1].x, face.pts[1].y);
    ctx.lineTo(face.pts[2].x, face.pts[2].y);
    ctx.lineTo(face.pts[3].x, face.pts[3].y);
    ctx.closePath();
    ctx.fillStyle = face.color;
    ctx.fill();
    if (face.outline) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
      ctx.lineWidth = 0.55;
      ctx.stroke();
    }
  }

  drawBoundingCube(ctx, basis, pixelSize, camera.fov);

  if (showOverlay) {
    ctx.save();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.78)';
    ctx.fillRect(12, 12, 248, 54);
    ctx.fillStyle = '#30394a';
    ctx.font = `700 ${Math.max(12, Math.round(pixelSize / 42))}px system-ui, sans-serif`;
    ctx.fillText(`stage ${stageData.stage}`, 24, 34);
    ctx.font = `600 ${Math.max(10, Math.round(pixelSize / 54))}px system-ui, sans-serif`;
    ctx.fillText('Drag to rotate. Scroll to zoom.', 24, 55);
    ctx.restore();
  }
}

function drawEmptyView(message = 'Render a mask to begin') {
  const canvas = els.view;
  const size = state.viewSize;
  canvas.style.width = `${size}px`;
  canvas.style.height = `${size}px`;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = els.background.value || '#ffffff';
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = '#667085';
  ctx.font = '700 28px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(message, size / 2, size / 2 - 10);
  ctx.font = '600 18px system-ui, sans-serif';
  ctx.fillText('Drag to rotate. Scroll to zoom after rendering.', size / 2, size / 2 + 28);
  ctx.textAlign = 'start';
}

function updateMeta(stageData, elapsedMs) {
  const grid = `${stageData.nx} x ${stageData.ny} x ${stageData.nz}`;
  const rule = `${stageData.retainedRuleCount}/${stageData.ruleBoxes}`;
  els.outputMeta.textContent = `Stage grid ${grid}; retained rule ${rule}; ${stageData.cells.length.toLocaleString()} occupied cells; ${stageData.faces.length.toLocaleString()} boundary faces; ${Math.round(elapsedMs)} ms.`;
  els.stageBadge.textContent = `stage ${stageData.stage}`;
}

function scheduleRender(delay = 160) {
  window.clearTimeout(state.renderTimer);
  state.renderTimer = window.setTimeout(() => {
    render().catch(error => setStatus(`Render failed: ${error.message}`));
  }, delay);
}

async function render() {
  const serial = ++state.renderSerial;
  readControls(true);
  const kept = countKept();
  els.stageBadge.textContent = `stage ${state.k}`;

  if (state.k > 0 && kept === 0) {
    drawEmptyView('The retained set is empty.');
    state.hasRendered = true;
    state.lastStage = null;
    setStatus('No boxes are retained. The stage is empty.');
    return;
  }

  const t0 = performance.now();
  state.isRendering = true;
  els.render.disabled = true;
  setStatus('Building cached surface geometry...');
  await sleep(0);

  const stageData = await buildStage(state.k);
  if (serial !== state.renderSerial) return;

  setStatus('Drawing perspective...');
  renderScene(els.view, stageData, state.camera);
  const elapsed = performance.now() - t0;

  state.lastStage = stageData;
  state.hasRendered = true;
  state.isRendering = false;
  els.render.disabled = false;
  updateMeta(stageData, elapsed);
  setStatus(`Rendered with the fast v11-style surface renderer. Camera changes reuse the cached stage.`);
}

function redrawFromCache() {
  if (!state.lastStage) return;
  readControls(false);
  renderScene(els.view, state.lastStage, state.camera);
}

function downloadPng() {
  if (!state.hasRendered || !state.lastStage) {
    setStatus('Render the 3D fractal before downloading.');
    return;
  }
  const link = document.createElement('a');
  link.download = `self-affine-3d-${state.n}x${state.m}x${state.p}-k${state.k}.png`;
  link.href = els.view.toDataURL('image/png');
  link.click();
}


function makeRng(seed) {
  let value = seed >>> 0;
  return function rng() {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function standardNormal(rng) {
  const u = Math.max(1e-12, rng());
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function createComplexField(size) {
  return {
    real: new Float64Array(size * size),
    imag: new Float64Array(size * size),
    description: ''
  };
}

function chooseRandomMode(choice, continuity) {
  if (choice === 'randomContinuous') return continuity === 'discontinuous' ? 'randomDiscontinuous' : 'randomContinuous';
  if (choice === 'randomDiscontinuous') return continuity === 'continuous' ? 'randomContinuous' : 'randomDiscontinuous';
  return choice;
}

function computeDigits(length, base, stage) {
  const digits = Array.from({ length: stage }, () => new Uint16Array(length));

  for (let i = 0; i < length; i += 1) {
    let value = (i + 0.5) / length;
    for (let s = 0; s < stage; s += 1) {
      let digit = Math.floor(value * base);
      if (digit < 0) digit = 0;
      if (digit >= base) digit = base - 1;
      digits[s][i] = digit;
      value = value * base - digit;
    }
  }

  return digits;
}

function computeCoordinateDigits(index, length, base, stage) {
  const digits = new Uint16Array(stage);
  let value = (index + 0.5) / length;
  for (let s = 0; s < stage; s += 1) {
    let digit = Math.floor(value * base);
    if (digit < 0) digit = 0;
    if (digit >= base) digit = base - 1;
    digits[s] = digit;
    value = value * base - digit;
  }
  return digits;
}

function readFunctionSlice(size) {
  if (!els.functionSlice) return Math.floor(size / 2);
  const fallback = Math.floor(size / 2);
  const slice = clampInt(els.functionSlice.value, 0, size - 1, fallback);
  els.functionSlice.min = '0';
  els.functionSlice.max = String(size - 1);
  els.functionSlice.value = String(slice);
  return slice;
}

function computeRetainedSliceMask(size, stage, sliceIndex) {
  const result = new Uint8Array(size * size);
  if (stage === 0) {
    result.fill(1);
    return result;
  }
  if (countKept() === 0) return result;

  const xDigits = computeDigits(size, state.n, stage);
  const yDigits = computeDigits(size, state.m, stage);
  const zDigits = computeCoordinateDigits(sliceIndex, size, state.p, stage);

  for (let y = 0; y < size; y += 1) {
    const rowDigits = yDigits.map(digits => digits[y]);
    const rowOffset = y * size;
    for (let x = 0; x < size; x += 1) {
      let alive = 1;
      for (let s = 0; s < stage; s += 1) {
        if (!state.mask[zDigits[s]][rowDigits[s]][xDigits[s][x]]) {
          alive = 0;
          break;
        }
      }
      result[rowOffset + x] = alive;
    }
  }

  return result;
}

function generateWholeGridFunction(size, sliceIndex) {
  const choice = chooseRandomMode(els.functionChoice.value, els.functionContinuity.value);
  const seed = clampInt(els.functionSeed.value, 1, 999999, 12345);
  els.functionSeed.value = String(seed);
  const rng = makeRng(seed);
  const field = createComplexField(size);
  const real = field.real;
  const imag = field.imag;
  const modes = [];
  const zz = (sliceIndex + 0.5) / size;

  if (choice === 'randomContinuous') {
    const modeCount = 18;
    for (let j = 0; j < modeCount; j += 1) {
      const ax = 1 + Math.floor(rng() * 5);
      const ay = 1 + Math.floor(rng() * 5);
      const az = 1 + Math.floor(rng() * 5);
      const amp = standardNormal(rng) / Math.pow(1 + ax * ax + ay * ay + az * az, 0.85);
      const phase = 2 * Math.PI * rng();
      modes.push([ax, ay, az, amp, phase]);
    }
  }

  for (let y = 0; y < size; y += 1) {
    const yy = (y + 0.5) / size;
    for (let x = 0; x < size; x += 1) {
      const xx = (x + 0.5) / size;
      const i = y * size + x;

      switch (choice) {
        case 'randomContinuous': {
          let value = 0;
          for (const [ax, ay, az, amp, phase] of modes) {
            value += amp * Math.cos(2 * Math.PI * (ax * xx + ay * yy + az * zz) + phase);
          }
          real[i] = value;
          field.description = 'continuous random 3D trigonometric field restricted to one z-slice';
          break;
        }
        case 'randomDiscontinuous': {
          real[i] = rng() * 2 - 1;
          field.description = 'discontinuous random slice noise';
          break;
        }
        case 'x':
          real[i] = xx - 0.5;
          field.description = 'centered x-coordinate';
          break;
        case 'y':
          real[i] = yy - 0.5;
          field.description = 'centered y-coordinate';
          break;
        case 'z':
          real[i] = zz - 0.5;
          field.description = 'centered z-coordinate on the selected slice';
          break;
        case 'linear':
          real[i] = xx + yy + zz - 1.5;
          field.description = 'centered x + y + z';
          break;
        case 'sine':
          real[i] = Math.sin(2 * Math.PI * (3 * xx + 2 * yy + zz)) + 0.55 * Math.cos(2 * Math.PI * (5 * xx - yy + 2 * zz));
          field.description = 'two smooth 3D sinusoidal waves restricted to one z-slice';
          break;
        case 'radial': {
          const dx = xx - 0.5;
          const dy = yy - 0.5;
          const dz = zz - 0.5;
          real[i] = Math.exp(-42 * (dx * dx + dy * dy + dz * dz));
          field.description = '3D radial Gaussian bump restricted to one z-slice';
          break;
        }
        case 'checker': {
          const addressDepth = Math.min(state.k, 5);
          const cx = Math.floor(xx * Math.pow(state.n, addressDepth));
          const cy = Math.floor(yy * Math.pow(state.m, addressDepth));
          const cz = Math.floor(zz * Math.pow(state.p, addressDepth));
          real[i] = (cx + cy + cz) % 2 === 0 ? 1 : -1;
          field.description = 'checker by finite 3D address parity';
          break;
        }
        case 'cohenPoint': {
          const width = 0.045;
          const dx = xx - 0.5;
          const dy = yy - 0.5;
          const dz = zz - 0.5;
          real[i] = Math.exp(-(dx * dx + dy * dy + dz * dz) / (2 * width * width));
          field.description = 'point localizer in the 3D cube';
          break;
        }
        case 'cohenCharacter': {
          const phase = 2 * Math.PI * (5 * xx + 3 * yy + 2 * zz);
          real[i] = Math.cos(phase);
          imag[i] = Math.sin(phase);
          field.description = '3D torus character exp(2pi i(5x+3y+2z))';
          break;
        }
        case 'cohenVerticalLine': {
          const dist = Math.abs(xx - 0.5);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.025 * 0.025)) * Math.cos(2 * Math.PI * (5 * yy + 2 * zz));
          field.description = 'coordinate-plane packet near x = 1/2';
          break;
        }
        case 'cohenDiagonalLine': {
          const dist = Math.abs(xx + yy + zz - 1.5) / Math.sqrt(3);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.03 * 0.03)) * Math.cos(2 * Math.PI * (4 * xx - 4 * yy + zz));
          field.description = 'diagonal-plane packet in the 3D cube';
          break;
        }
        case 'cohenSkewLine': {
          const dist = Math.abs(2 * xx - yy + zz - 0.65) / Math.sqrt(6);
          real[i] = Math.exp(-(dist * dist) / (2 * 0.03 * 0.03)) * Math.cos(2 * Math.PI * (3 * xx + yy - 2 * zz));
          field.description = 'skew-plane packet in the 3D cube';
          break;
        }
        default:
          real[i] = 0;
          field.description = 'zero function';
      }
    }
  }

  const normBefore = l2NormOnSquare(real, imag, null, size);
  let normalized = false;
  let scale = 1;
  if (normBefore > 1e-14) {
    scale = 1 / normBefore;
    for (let i = 0; i < real.length; i += 1) {
      real[i] *= scale;
      imag[i] *= scale;
    }
    normalized = true;
  }

  field.choice = choice;
  field.seed = seed;
  field.sliceIndex = sliceIndex;
  field.normBefore = normBefore;
  field.scale = scale;
  field.normalized = normalized;
  return field;
}

function l2NormOnSquare(real, imag, mask, size) {
  let sum = 0;
  for (let i = 0; i < real.length; i += 1) {
    if (mask && !mask[i]) continue;
    sum += real[i] * real[i] + imag[i] * imag[i];
  }
  return Math.sqrt(sum / (size * size));
}

function meanOnMask(real, imag, mask) {
  let sumReal = 0;
  let sumAbsSq = 0;
  let count = 0;
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    sumReal += real[i];
    sumAbsSq += real[i] * real[i] + imag[i] * imag[i];
    count += 1;
  }
  return {
    meanReal: count ? sumReal / count : 0,
    rmsOnSet: count ? Math.sqrt(sumAbsSq / count) : 0,
    count
  };
}

function fft1d(real, imag, inverse) {
  const n = real.length;
  let j = 0;
  for (let i = 1; i < n; i += 1) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = real[i];
      const ti = imag[i];
      real[i] = real[j];
      imag[i] = imag[j];
      real[j] = tr;
      imag[j] = ti;
    }
  }

  for (let len = 2; len <= n; len <<= 1) {
    const angle = (inverse ? 2 : -2) * Math.PI / len;
    const wLenR = Math.cos(angle);
    const wLenI = Math.sin(angle);
    for (let i = 0; i < n; i += len) {
      let wr = 1;
      let wi = 0;
      const half = len >> 1;
      for (let k = 0; k < half; k += 1) {
        const even = i + k;
        const odd = even + half;
        const ur = real[even];
        const ui = imag[even];
        const vr = real[odd] * wr - imag[odd] * wi;
        const vi = real[odd] * wi + imag[odd] * wr;
        real[even] = ur + vr;
        imag[even] = ui + vi;
        real[odd] = ur - vr;
        imag[odd] = ui - vi;
        const nextWr = wr * wLenR - wi * wLenI;
        wi = wr * wLenI + wi * wLenR;
        wr = nextWr;
      }
    }
  }

  if (inverse) {
    for (let i = 0; i < n; i += 1) {
      real[i] /= n;
      imag[i] /= n;
    }
  }
}

function fft2dUnitary(inputReal, inputImag, size) {
  const real = new Float64Array(inputReal);
  const imag = new Float64Array(inputImag);
  const rowR = new Float64Array(size);
  const rowI = new Float64Array(size);

  for (let y = 0; y < size; y += 1) {
    const offset = y * size;
    for (let x = 0; x < size; x += 1) {
      rowR[x] = real[offset + x];
      rowI[x] = imag[offset + x];
    }
    fft1d(rowR, rowI, false);
    for (let x = 0; x < size; x += 1) {
      real[offset + x] = rowR[x];
      imag[offset + x] = rowI[x];
    }
  }

  const colR = new Float64Array(size);
  const colI = new Float64Array(size);
  for (let x = 0; x < size; x += 1) {
    for (let y = 0; y < size; y += 1) {
      const index = y * size + x;
      colR[y] = real[index];
      colI[y] = imag[index];
    }
    fft1d(colR, colI, false);
    for (let y = 0; y < size; y += 1) {
      const index = y * size + x;
      real[index] = colR[y] / size;
      imag[index] = colI[y] / size;
    }
  }

  return { real, imag };
}

function colorDiverging(value, maxAbs) {
  if (maxAbs <= 1e-14) return [245, 247, 251];
  const t = Math.max(-1, Math.min(1, value / maxAbs));
  if (t >= 0) {
    const u = t;
    return [
      Math.round(250 - 70 * u),
      Math.round(246 - 150 * u),
      Math.round(238 - 170 * u)
    ];
  }
  const u = -t;
  return [
    Math.round(238 - 160 * u),
    Math.round(246 - 120 * u),
    Math.round(250 - 35 * u)
  ];
}

function colorMagnitude(value, maxValue) {
  if (maxValue <= 1e-14) return [245, 247, 251];
  const t = Math.max(0, Math.min(1, value / maxValue));
  return [
    Math.round(250 - 210 * t),
    Math.round(247 - 130 * Math.sqrt(t)),
    Math.round(238 - 20 * t)
  ];
}

function drawFunctionHeatMap(canvas, real, imag, mask, size) {
  canvas.width = size;
  canvas.height = size;
  canvas.style.aspectRatio = '1 / 1';
  const ctx = canvas.getContext('2d');
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  let maxAbs = 0;
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    maxAbs = Math.max(maxAbs, Math.abs(real[i]));
  }

  for (let i = 0; i < mask.length; i += 1) {
    const offset = i * 4;
    if (!mask[i]) {
      data[offset] = 255;
      data[offset + 1] = 255;
      data[offset + 2] = 255;
      data[offset + 3] = 255;
      continue;
    }
    const [r, g, b] = colorDiverging(real[i], maxAbs);
    data[offset] = r;
    data[offset + 1] = g;
    data[offset + 2] = b;
    data[offset + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
}

function drawFourierHeatMap(canvas, fourierReal, fourierImag, mask, size) {
  canvas.width = size;
  canvas.height = size;
  canvas.style.aspectRatio = '1 / 1';
  const ctx = canvas.getContext('2d');
  const imageData = ctx.createImageData(size, size);
  const data = imageData.data;
  const half = size >> 1;
  const visibleLogMag = new Float64Array(size * size);
  let maxLogMag = 0;

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const displayIndex = y * size + x;
      if (!mask[displayIndex]) continue;
      const sx = (x + half) % size;
      const sy = (y + half) % size;
      const sourceIndex = sy * size + sx;
      const mag = Math.hypot(fourierReal[sourceIndex], fourierImag[sourceIndex]);
      const logMag = Math.log1p(mag);
      visibleLogMag[displayIndex] = logMag;
      if (logMag > maxLogMag) maxLogMag = logMag;
    }
  }

  for (let i = 0; i < mask.length; i += 1) {
    const offset = i * 4;
    if (!mask[i]) {
      data[offset] = 255;
      data[offset + 1] = 255;
      data[offset + 2] = 255;
      data[offset + 3] = 255;
      continue;
    }
    const [r, g, b] = colorMagnitude(visibleLogMag[i], maxLogMag);
    data[offset] = r;
    data[offset + 1] = g;
    data[offset + 2] = b;
    data[offset + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
}

function restrictFieldToMask(field, mask) {
  const real = new Float64Array(field.real.length);
  const imag = new Float64Array(field.imag.length);
  for (let i = 0; i < mask.length; i += 1) {
    if (!mask[i]) continue;
    real[i] = field.real[i];
    imag[i] = field.imag[i];
  }
  return { real, imag };
}

function l2NormOfCenteredFourierRestrictedToMask(fourierReal, fourierImag, mask, size) {
  const half = size >> 1;
  let sum = 0;
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const displayIndex = y * size + x;
      if (!mask[displayIndex]) continue;
      const sx = (x + half) % size;
      const sy = (y + half) % size;
      const sourceIndex = sy * size + sx;
      sum += fourierReal[sourceIndex] * fourierReal[sourceIndex] + fourierImag[sourceIndex] * fourierImag[sourceIndex];
    }
  }
  return Math.sqrt(sum / (size * size));
}

async function generateFunctionAnalysis() {
  if (!els.functionCanvas || !els.fourierCanvas) return;
  readControls(true);

  const size = clampInt(els.functionSize.value, 64, 512, 128);
  if ((size & (size - 1)) !== 0) {
    setStatus('Function sample size must be a power of two.');
    return;
  }
  els.functionSize.value = String(size);
  const sliceIndex = readFunctionSlice(size);
  const zValue = (sliceIndex + 0.5) / size;

  if (els.functionBadge) els.functionBadge.textContent = 'computing';
  await sleep(0);

  const setMask = computeRetainedSliceMask(size, state.k, sliceIndex);
  const field = generateWholeGridFunction(size, sliceIndex);
  const restricted = restrictFieldToMask(field, setMask);
  const fourier = fft2dUnitary(restricted.real, restricted.imag, size);

  drawFunctionHeatMap(els.functionCanvas, restricted.real, restricted.imag, setMask, size);
  drawFourierHeatMap(els.fourierCanvas, fourier.real, fourier.imag, setMask, size);

  const count = setMask.reduce((acc, value) => acc + value, 0);
  const area = count / (size * size);
  const functionL2 = l2NormOnSquare(restricted.real, restricted.imag, null, size);
  const fourierFullL2 = l2NormOnSquare(fourier.real, fourier.imag, null, size);
  const fourierRestrictedL2 = l2NormOfCenteredFourierRestrictedToMask(fourier.real, fourier.imag, setMask, size);
  const stats = meanOnMask(restricted.real, restricted.imag, setMask);
  const parsevalError = Math.abs(functionL2 - fourierFullL2);

  if (els.functionMeta) {
    els.functionMeta.innerHTML = [
      metaItem('Function model', field.description),
      metaItem('Whole-grid normalization', field.normalized ? `||f||_2 = 1, scale ${formatNumber(field.scale, 5)}` : 'not applied'),
      metaItem('Depth slice', `${sliceIndex} / ${size - 1}, z = ${formatNumber(zValue, 5)}`),
      metaItem('Retained slice pixels', `${count.toLocaleString()} / ${(size * size).toLocaleString()}`),
      metaItem('Estimated |E_z|', formatNumber(area, 6)),
      metaItem('||1_Ez f||_2', formatNumber(functionL2, 7)),
      metaItem('||1_Ez F2(1_Ez f)||_2', formatNumber(fourierRestrictedL2, 7)),
      metaItem('Full Parseval check ||F2(1_Ez f)||_2', formatNumber(fourierFullL2, 7)),
      metaItem('Parseval difference', formatNumber(parsevalError, 4)),
      metaItem('Mean of real part on E_z', formatNumber(stats.meanReal, 6)),
      metaItem('RMS on E_z', formatNumber(stats.rmsOnSet, 6))
    ].join('');
  }

  if (els.functionBadge) els.functionBadge.textContent = `slice ${sliceIndex}, ${size} x ${size}`;
  state.functionReady = true;
  state.lastFunctionResult = {
    size,
    sliceIndex,
    count,
    functionL2,
    fourierRestrictedL2,
    fourierFullL2
  };
  setStatus(`Generated 3D slice function and Fourier heat maps. Restricted Fourier L2 = ${formatNumber(fourierRestrictedL2, 6)}.`);
}

function scheduleFunctionAnalysis() {
  if (!state.functionReady) return;
  window.clearTimeout(state.functionTimer);
  state.functionTimer = window.setTimeout(() => {
    generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
  }, 260);
}

function rgbTo332(r, g, b) {
  return ((r & 0xe0)) | ((g & 0xe0) >> 3) | (b >> 6);
}

function make332Palette() {
  const palette = [];
  for (let i = 0; i < 256; i += 1) {
    const r = i & 0xe0;
    const g = (i & 0x1c) << 3;
    const b = (i & 0x03) << 6;
    palette.push(r | (r >> 3) | (r >> 6));
    palette.push(g | (g >> 3) | (g >> 6));
    palette.push(b | (b >> 2) | (b >> 4) | (b >> 6));
  }
  return palette;
}

function packCodes9(codes) {
  const bytes = [];
  let acc = 0;
  let bits = 0;
  for (const code of codes) {
    acc |= code << bits;
    bits += 9;
    while (bits >= 8) {
      bytes.push(acc & 255);
      acc >>= 8;
      bits -= 8;
    }
  }
  if (bits > 0) bytes.push(acc & 255);
  return bytes;
}

function literalLzw(indices) {
  const clear = 256;
  const end = 257;
  const codes = [clear];
  let sinceClear = 0;
  for (const value of indices) {
    if (sinceClear >= 250) {
      codes.push(clear);
      sinceClear = 0;
    }
    codes.push(value);
    sinceClear += 1;
  }
  codes.push(end);
  return packCodes9(codes);
}

function pushWord(out, value) {
  out.push(value & 255, (value >> 8) & 255);
}

function pushAscii(out, text) {
  for (let i = 0; i < text.length; i += 1) out.push(text.charCodeAt(i));
}

function pushSubBlocks(out, bytes) {
  for (let i = 0; i < bytes.length; i += 255) {
    const chunk = bytes.slice(i, i + 255);
    out.push(chunk.length, ...chunk);
  }
  out.push(0);
}

function makeGif(frames, width, height, delayCs) {
  const out = [];
  pushAscii(out, 'GIF89a');
  pushWord(out, width);
  pushWord(out, height);
  out.push(0xf7, 0, 0);
  out.push(...make332Palette());

  out.push(0x21, 0xff, 0x0b);
  pushAscii(out, 'NETSCAPE2.0');
  out.push(0x03, 0x01, 0x00, 0x00, 0x00);

  for (const indices of frames) {
    out.push(0x21, 0xf9, 0x04, 0x00);
    pushWord(out, delayCs);
    out.push(0x00, 0x00);
    out.push(0x2c);
    pushWord(out, 0);
    pushWord(out, 0);
    pushWord(out, width);
    pushWord(out, height);
    out.push(0x00);
    out.push(0x08);
    pushSubBlocks(out, literalLzw(indices));
  }

  out.push(0x3b);
  return new Blob([new Uint8Array(out)], { type: 'image/gif' });
}

async function downloadGif() {
  readControls(true);
  const maxStage = Math.min(4, Math.max(1, state.k));
  const fps = 30;
  const seconds = 4;
  const frameCount = fps * seconds;
  const gifSize = Math.min(360, Math.max(220, Math.round(state.viewSize * state.quality / 100)));
  const offscreen = document.createElement('canvas');
  const frames = [];

  els.downloadGif.disabled = true;
  setStatus('Rendering GIF frames...');

  for (let i = 0; i < frameCount; i += 1) {
    const t = i / frameCount;
    const stage = 1 + Math.min(maxStage - 1, Math.floor(t * maxStage));
    const stageData = await buildStage(stage);
    const camera = {
      yaw: state.camera.yaw + t * Math.PI * 2,
      pitch: 0.48 + 0.16 * Math.sin(t * Math.PI * 2),
      distance: Math.max(8.2, state.camera.distance + 0.5),
      fov: state.camera.fov
    };
    renderScene(offscreen, stageData, camera, {
      displaySize: gifSize,
      pixelSize: gifSize,
      quality: 100,
      showOverlay: false
    });
    const data = offscreen.getContext('2d').getImageData(0, 0, gifSize, gifSize).data;
    const indexed = new Uint8Array(gifSize * gifSize);
    for (let j = 0, p = 0; j < data.length; j += 4, p += 1) {
      indexed[p] = rgbTo332(data[j], data[j + 1], data[j + 2]);
    }
    frames.push(indexed);
    if (i % 4 === 0) {
      setStatus(`Rendering GIF frames... ${i + 1}/${frameCount}`);
      await sleep(0);
    }
  }

  setStatus('Encoding GIF...');
  await sleep(0);
  const blob = makeGif(frames, gifSize, gifSize, Math.max(1, Math.round(100 / fps)));
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.download = `self-affine-3d-orbit-${state.n}x${state.m}x${state.p}-k1-${maxStage}-30fps.gif`;
  link.href = url;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 30000);
  els.downloadGif.disabled = false;
  setStatus(`Downloaded ${fps} fps GIF through stages 1-${maxStage}.`);
}

function bindCameraEvents() {
  els.view.addEventListener('pointerdown', event => {
    event.preventDefault();
    state.drag = {
      x: event.clientX,
      y: event.clientY,
      yaw: state.camera.yaw,
      pitch: state.camera.pitch
    };
    els.view.setPointerCapture(event.pointerId);
    els.view.classList.add('dragging');
  });

  els.view.addEventListener('pointermove', event => {
    if (!state.drag) return;
    const dx = event.clientX - state.drag.x;
    const dy = event.clientY - state.drag.y;
    state.camera.yaw = state.drag.yaw + dx * 0.008;
    state.camera.pitch = clamp(state.drag.pitch + dy * 0.006, -1.25, 1.25);
    redrawFromCache();
  });

  const stopDrag = event => {
    if (!state.drag) return;
    state.drag = null;
    if (event && els.view.hasPointerCapture(event.pointerId)) {
      els.view.releasePointerCapture(event.pointerId);
    }
    els.view.classList.remove('dragging');
  };

  els.view.addEventListener('pointerup', stopDrag);
  els.view.addEventListener('pointercancel', stopDrag);
  els.view.addEventListener('pointerleave', stopDrag);

  els.view.addEventListener('wheel', event => {
    event.preventDefault();
    const factor = Math.exp(event.deltaY * 0.0012);
    state.camera.distance = clamp(state.camera.distance * factor, 3.0, 24.0);
    redrawFromCache();
  }, { passive: false });
}

function bindEvents() {
  els.applyGrid.addEventListener('click', () => {
    readControls(true);
    drawGrid();
    updateKeptCount();
    setStatus(`Grid is ${state.n} x ${state.m} x ${state.p}. Existing overlapping cells were preserved.`);
    scheduleRender(80);
    scheduleFunctionAnalysis();
  });

  els.render.addEventListener('click', () => {
    render().catch(error => setStatus(`Render failed: ${error.message}`));
  });

  els.clear.addEventListener('click', () => { fillMask(false); setStatus('Cleared the 3D grid.'); });
  els.fill.addEventListener('click', () => { fillMask(true); setStatus('Filled the 3D grid.'); });
  els.invert.addEventListener('click', () => { invertMask(); setStatus('Inverted the 3D grid.'); });
  els.random.addEventListener('click', () => { randomMask(); setStatus(`Randomized the 3D grid at ${els.density.value}% density.`); });
  els.loadPreset.addEventListener('click', () => loadPreset(els.preset.value));
  els.download.addEventListener('click', downloadPng);
  if (els.downloadGif) els.downloadGif.addEventListener('click', () => downloadGif().catch(error => { els.downloadGif.disabled = false; setStatus(`GIF failed: ${error.message}`); }));

  els.density.addEventListener('input', () => { els.densityLabel.textContent = `${els.density.value}%`; });
  if (els.quality) els.quality.addEventListener('input', () => { readControls(false); redrawFromCache(); });

  for (const input of [els.columns, els.rows, els.layers]) {
    input.addEventListener('input', () => {
      readControls(true);
      drawGrid();
      updateKeptCount();
      scheduleRender(220);
      scheduleFunctionAnalysis();
    });
  }

  for (const input of [els.iterations, els.resolution]) {
    input.addEventListener('input', () => {
      readControls(false);
      scheduleRender(180);
      scheduleFunctionAnalysis();
    });
  }

  for (const input of [els.foreground, els.background]) {
    input.addEventListener('input', () => {
      if (state.lastStage) redrawFromCache();
      else scheduleRender(120);
    });
  }

  els.slice.addEventListener('input', () => { readControls(false); drawGrid(); });

  if (els.generateFunction) {
    els.generateFunction.addEventListener('click', () => {
      window.clearTimeout(state.functionTimer);
      generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
    });
  }

  if (els.randomizeFunctionSeed) {
    els.randomizeFunctionSeed.addEventListener('click', () => {
      els.functionSeed.value = String(1 + Math.floor(Math.random() * 999999));
      generateFunctionAnalysis().catch(error => setStatus(`Function analysis failed: ${error.message}`));
    });
  }

  for (const control of [els.functionChoice, els.functionSize, els.functionSlice, els.functionContinuity, els.functionSeed]) {
    if (!control) continue;
    control.addEventListener('input', () => {
      state.functionReady = true;
      scheduleFunctionAnalysis();
    });
    control.addEventListener('change', () => {
      state.functionReady = true;
      scheduleFunctionAnalysis();
    });
  }

  els.gridCanvas.addEventListener('pointerdown', onPointerDown);
  els.gridCanvas.addEventListener('pointermove', onPointerMove);
  els.gridCanvas.addEventListener('pointerup', stopPainting);
  els.gridCanvas.addEventListener('pointercancel', stopPainting);
  els.gridCanvas.addEventListener('pointerleave', stopPainting);
  window.addEventListener('resize', () => { drawGrid(); redrawFromCache(); });
  bindCameraEvents();
}

function init() {
  bindEvents();
  loadPreset('menger');
  drawEmptyView();
  els.densityLabel.textContent = `${els.density.value}%`;
  if (els.qualityLabel) els.qualityLabel.textContent = `${els.quality.value}%`;
  if (els.functionMeta) {
    els.functionMeta.innerHTML = metaItem('Function analysis', 'Generate a z-slice heat map after choosing a function.');
  }
  setStatus('Ready. The v11-style fast renderer is active.');
}

init();
